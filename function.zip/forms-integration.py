import boto3
import os
import json
from botocore.config import Config

def get_answers(raw_answers: json) -> json:
    result = {}
    for name, value in raw_answers.get('answer').get('data').items():
        if name.startswith('answer_choices_'):
            choices = []
            for c in value.get('value'):
                choices.append(c.get('text'))
            result[name] = ','.join(choices)
        else:
            result[name] = value.get('value')
    return result

def handler(event, context):
    headers = event.get('headers')
    form_id = headers.get('X-Form-Id')
    answer_id = headers.get('X-Form-Answer-Id')

    body_json = json.loads(event.get('body'))
    answers_json = get_answers(body_json)

    aws_access_key_id = os.environ['KEY']
    aws_secret_access_key = os.environ['SECRET_KEY']
    bucket_name = os.environ['BUCKET']

    s3 = boto3.client(service_name='s3',
                    aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key,
                    endpoint_url='https://storage.yandexcloud.net', region_name='ru-central1',
                    config=Config(request_checksum_calculation="when_required"))

    s3.put_object(Bucket=bucket_name, Key=f"{form_id}/{answer_id}.json", Body=json.dumps(answers_json))

    return {
        'statusCode': 200,
        'body': "OK",
        'headers': {
            'Content-Type': 'text/plain',
        }
    }

